from pyfingerprint import PyFingerprint
from machine import UART
import time

class AS608:
    def __init__(self, tx=17, rx=16, baudrate=57600):
        
        self.uart = UART(2, baudrate=baudrate, tx=tx, rx=rx)
        time.sleep(1)

    def _read(self):
        time.sleep(0.5)
        data = self.uart.read()
        return data

    def _write(self, packet):
        self.uart.write(packet)

    def capture_finger(self):
        """
        Forsøger at tage et fingerbillede.
        Returnerer True hvis der er en finger.
        Returnerer False hvis ingen finger er tilstede.
        """

        
        packet = b'\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x03\x01\x00\x05'

        self._write(packet)
        resp = self._read()

        if resp is None:
            return False

        
        if b'\x00' in resp:
            return True
        else:
            return False