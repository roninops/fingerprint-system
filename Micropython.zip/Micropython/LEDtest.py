from machine import UART
import time

uart = UART(2, baudrate=9600, tx=17, rx=16)

cmd_led_on = b'\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x03\x12\x01\x16'

uart.write(cmd_led_on)

time.sleep(0.2)

data = uart.read()
print("Svar:", data)