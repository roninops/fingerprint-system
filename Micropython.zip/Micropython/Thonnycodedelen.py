from machine import UART
import time

uart = UART(
    2,
    baudrate=57600,
    tx=17,
    rx=16,
    timeout=200
)

ADDR = b'\xFF\xFF\xFF\xFF'

def send_packet(pkt_type, payload):
    length = len(payload) + 2
    packet = (
        b'\xEF\x01' +
        ADDR +
        bytes([pkt_type]) +
        bytes([length >> 8, length & 0xFF]) +
        payload
    )

    checksum = pkt_type + (length >> 8) + (length & 0xFF)
    for b in payload:
        checksum += b

    packet += bytes([checksum >> 8, checksum & 0xFF])
    uart.write(packet)
    time.sleep(0.1)

def read_resp(timeout=1000):
    start = time.ticks_ms()
    data = b""
    while time.ticks_diff(time.ticks_ms(), start) < timeout:
        part = uart.read()
        if part:
            data += part
        time.sleep(0.01)
    return data

def ok(resp):
    return resp and len(resp) > 9 and resp[9] == 0x00

def get_image():
    send_packet(0x01, b'\x01')
    return read_resp()

def image2tz():
    send_packet(0x01, b'\x02\x01')
    return read_resp()

def search():
    # search in whole database
    send_packet(0x01, b'\x04\x01\x00\x00\x03\xE8')  # 0–1000
    return read_resp()


print("=== FINGERPRINT READ START ===")
print("Læg finger på sensoren")

while True:
    r = get_image()
    if not ok(r):
        time.sleep(0.3)
        continue

    r = image2tz()
    if not ok(r):
        print("Kunne ikke konvertere billede")
        time.sleep(0.5)
        continue

    r = search()
    if r and len(r) > 13 and r[9] == 0x00:
        fid = (r[10] << 8) | r[11]
        print("✅ Finger genkendt – ID:", fid)
        time.sleep(2)
    else:
        print("❌ Finger ikke fundet")
        time.sleep(1)
