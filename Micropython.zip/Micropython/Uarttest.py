from machine import UART
import time

uart = UART(2, baudrate=9600, tx=17, rx=16)

# Dette er “GetImage” kommando i simple-mode-kompatibel form
cmd = b'\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x03\x01\x00\x05'

print("Fingerdetektor startet...")

while True:
    uart.write(cmd)
    time.sleep(0.2)
    data = uart.read()

    if data:
        status = data[-1]  # sidste byte er statuskoden

        if status == 0x00:
            print("👉 Finger registreret!")
        elif status == 0x02:
            print("Ingen finger...")
        else:
            print("Ukendt svar:", hex(status))

    time.sleep(0.5)