# config.py

WIFI_SSID = "TP-Link_769B"
WIFI_PASS = "tp88399997"

SERVER_IP = "192.168.0.36"   # din server PC IP
ACCESS_PATH = "/access/"    # endpoint

FINGER_TX = 17
FINGER_RX = 16

SERVO_PIN = 5
