from machine import UART
import time

uart = UART(
    2,
    baudrate=57600,
    tx=17,
    rx=16,
    timeout=200
)

ADDR = b'\xFF\xFF\xFF\xFF'

def send_packet(pkt_type, payload):
    length = len(payload) + 2
    packet = (
        b'\xEF\x01' +
        ADDR +
        bytes([pkt_type]) +
        bytes([length >> 8, length & 0xFF]) +
        payload
    )

    checksum = pkt_type + (length >> 8) + (length & 0xFF)
    for b in payload:
        checksum += b

    packet += bytes([checksum >> 8, checksum & 0xFF])
    uart.write(packet)
    time.sleep(0.1)

def read_resp(timeout=1000):
    start = time.ticks_ms()
    data = b""
    while time.ticks_diff(time.ticks_ms(), start) < timeout:
        part = uart.read()
        if part:
            data += part
        time.sleep(0.01)
    return data

def ok(resp):
    return resp and len(resp) > 9 and resp[9] == 0x00

def get_image():
    send_packet(0x01, b'\x01')
    return read_resp()

def image2tz(buf):
    send_packet(0x01, b'\x02' + bytes([buf]))
    return read_resp()

def reg_model():
    send_packet(0x01, b'\x05')
    return read_resp()

def store(fid):
    send_packet(
        0x01,
        b'\x06\x01' +
        bytes([(fid >> 8) & 0xFF, fid & 0xFF])
    )
    return read_resp()


print("=== ENROLL START ===")
FID = int(input("Indtast Fingerprint ID (fx 1): "))

print("Læg finger på (1/2)")
while True:
    r = get_image()
    if ok(r):
        print("Billede 1 OK")
        break
    time.sleep(0.3)

r = image2tz(1)
if not ok(r):
    print("❌ image2tz 1 fejlede")
    raise SystemExit

print("Fjern finger")
time.sleep(2)

print("Læg samme finger på igen (2/2)")
while True:
    r = get_image()
    if ok(r):
        print("Billede 2 OK")
        break
    time.sleep(0.3)

r = image2tz(2)
if not ok(r):
    print("❌ image2tz 2 fejlede")
    raise SystemExit

r = reg_model()
if not ok(r):
    print("❌ regModel fejlede")
    raise SystemExit

r = store(FID)
if ok(r):
    print("✅ Fingeraftryk GEMT med ID:", FID)
else:
    print("❌ Store fejlede – ID findes muligvis allerede")
