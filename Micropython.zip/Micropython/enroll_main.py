from fingerprint import Fingerprint
import config
import time

fp = Fingerprint(
    tx=config.FINGER_TX,
    rx=config.FINGER_RX
)

FID = 1   # Fingerprint ID der gemmes i sensoren

print("=== ENROLL START ===")
print("ID:", FID)

# 1. Første scan
print("Læg finger på sensoren (1/2)")
while True:
    resp = fp.get_image()
    if resp and resp[9] == 0x00:
        print("Billede 1 OK")
        break
    time.sleep(0.2)

if fp.image2Tz(1)[9] != 0x00:
    print("Fejl i image2Tz (1)")
    raise SystemExit

print("Fjern finger")
time.sleep(2)

# 2. Andet scan
print("Læg finger på igen (2/2)")
while True:
    resp = fp.get_image()
    if resp and resp[9] == 0x00:
        print("Billede 2 OK")
        break
    time.sleep(0.2)

if fp.image2Tz(2)[9] != 0x00:
    print("Fejl i image2Tz (2)")
    raise SystemExit

# 3. Kombiner
fp._write(b'\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x03\x05\x00\x09')
resp = fp._read()
if resp[9] != 0x00:
    print("regModel fejlede")
    raise SystemExit

# 4. Gem
high = (FID >> 8) & 0xFF
low = FID & 0xFF
checksum = 0x06 + high + low + 0x01
cmd = b'\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x06\x06\x01' + bytes([high, low, checksum])
fp._write(cmd)
resp = fp._read()

if resp[9] == 0x00:
    print("✅ FINGER GEMT MED ID", FID)
else:
    print("❌ Store fejlede")

print("=== ENROLL SLUT ===")
