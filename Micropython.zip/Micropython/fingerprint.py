from machine import UART
import time


class Fingerprint:
    def __init__(self):
        self.uart = UART(
            2,
            tx=26,
            rx=25,
            baudrate=9600,
            timeout=200
        )
        time.sleep(0.2)

    def _write(self, data):
        self.uart.write(data)
        time.sleep(0.05)

    def _read_packet(self, timeout=700):
        start = time.ticks_ms()
        buf = b""

        while time.ticks_diff(time.ticks_ms(), start) < timeout:
            part = self.uart.read()
            if part:
                buf += part

                # find AS608 header EF 01
                idx = buf.find(b'\xEF\x01')
                if idx != -1 and len(buf) >= idx + 12:
                    return buf[idx:]
            time.sleep(0.01)

        return None

    def get_image(self):
        self._write(b'\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x03\x01\x00\x05')
        return self._read_packet()

    def get_status(self, packet):
        if not packet or len(packet) < 10:
            return None
        return packet[9]
