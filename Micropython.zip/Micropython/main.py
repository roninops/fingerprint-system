from machine import UART
import time
import network
import socket

# ================== WIFI ==================
SSID = "COMHEM_C8708E"
PASSWORD = "k2k2wrh9"

def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(False)
    time.sleep(1)
    wlan.active(True)

    wlan.connect(SSID, PASSWORD)
    print("Forbinder til WiFi...")

    for _ in range(20):
        if wlan.isconnected():
            print("WiFi forbundet:", wlan.ifconfig())
            return True
        time.sleep(1)

    print("WiFi fejlede")
    return False


# ================== SERVER ==================
SERVER_IP = "192.168.0.36"
SERVER_PORT = 8000

def check_access(fid):
    host = SERVER_IP
    port = SERVER_PORT
    path = "/access/{}".format(fid)

    try:
        addr = socket.getaddrinfo(
            host,
            port,
            socket.AF_INET,      # 🔥 TVING IPv4
            socket.SOCK_STREAM
        )[0][-1]

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(5)

        print("Forbinder til server...")
        s.connect(addr)

        request = (
            "GET {} HTTP/1.1\r\n"
            "Host: {}\r\n"
            "Connection: close\r\n\r\n"
        ).format(path, host)

        print("Sender request")
        s.send(request.encode())

        response = b""
        while True:
            data = s.recv(1024)
            if not data:
                break
            response += data

        s.close()

        print("Rå server-respons:")
        print(response)

        return response

    except Exception as e:
        print("Server-fejl:", e)
        return None


# ================== FINGERPRINT ==================
uart = UART(
    2,
    baudrate=57600,
    tx=17,
    rx=16,
    timeout=200
)

ADDR = b'\xFF\xFF\xFF\xFF'

def send_packet(pkt_type, payload):
    length = len(payload) + 2
    packet = (
        b'\xEF\x01' +
        ADDR +
        bytes([pkt_type]) +
        bytes([length >> 8, length & 0xFF]) +
        payload
    )

    checksum = pkt_type + (length >> 8) + (length & 0xFF)
    for b in payload:
        checksum += b

    packet += bytes([checksum >> 8, checksum & 0xFF])
    uart.write(packet)
    time.sleep(0.1)

def read_resp(timeout=1000):
    start = time.ticks_ms()
    data = b""
    while time.ticks_diff(time.ticks_ms(), start) < timeout:
        part = uart.read()
        if part:
            data += part
        time.sleep(0.01)
    return data

def ok(resp):
    return resp and len(resp) > 9 and resp[9] == 0x00

def get_image():
    send_packet(0x01, b'\x01')
    return read_resp()

def image2tz():
    send_packet(0x01, b'\x02\x01')
    return read_resp()

def search():
    send_packet(0x01, b'\x04\x01\x00\x00\x03\xE8')
    return read_resp()


# ================== MAIN ==================
print("=== SYSTEM START ===")

if not connect_wifi():
    raise SystemExit

print("System klar – scan finger")

while True:
    r = get_image()
    if not ok(r):
        time.sleep(0.3)
        continue

    r = image2tz()
    if not ok(r):
        time.sleep(0.5)
        continue

    r = search()
    if r and len(r) > 13 and r[9] == 0x00:
        fid = (r[10] << 8) | r[11]
        print("Fingerprint ID:", fid)

        response = check_access(fid)
        print("Server svar:", response)

        time.sleep(2)
    else:
        print("Finger ikke fundet")
        time.sleep(1)


